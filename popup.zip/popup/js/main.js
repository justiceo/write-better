
class BrowserAction {
    init() {
      document.getElementById("hostname").innerHTML = window.location.hostname;
      this.setupSiteCheckbox();
  
      document.getElementById("url-path").innerHTML = window.location;
      this.setupPageCheckbox();
    }
  
    setupSiteCheckbox() {
      const cb = document.getElementById("hostname-checkbox");
      const origin = window.location.origin; // "https://www.example.com:80"
      cb.checked = !window.localStorage.getItem(origin);
      cb.addEventListener("change", (event) => {
        if (event.currentTarget.checked) {
          // Enable site and all its pages
          for (let key in window.localStorage) {
            if (key == origin || key.startsWith(origin)) {
              window.localStorage.removeItem(key);
            }
          }
          document.getElementById("url-path-checkbox").disabled = false;
        } else {
          // Disable site (and current page). Also disable current page button.
          window.localStorage.setItem(origin, true);
          window.localStorage.setItem(origin + window.location.pathname, true);
          document.getElementById("url-path-checkbox").checked = false;
          document.getElementById("url-path-checkbox").disabled = false;
        }
      });
    }
  
    setupPageCheckbox() {
      const cb = document.getElementById("url-path-checkbox");
      const origin = window.location.origin;
      const fullPath = origin + window.location.pathname; // "http://example.com/hello"
      cb.checked =
        !window.localStorage.getItem(origin) &&
        !window.localStorage.getItem(fullPath);
      cb.addEventListener("change", (event) => {
        if (event.currentTarget.checked) {
          // Enable page
          window.localStorage.removeItem(fullPath);
        } else {
          // Disable page
          window.localStorage.setItem(fullPath, true);
        }
      });
    }
  }
  
  new BrowserAction().init();
  